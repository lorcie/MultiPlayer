/**
    Copyright 2014-2015 Amazon.com, Inc. or its affiliates. All Rights Reserved.

    Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance with the License. A copy of the License is located at

        http://aws.amazon.com/apache2.0/

    or in the "license" file accompanying this file. This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.
*/

'use strict';
var AWS = require("aws-sdk");
var originalquestions = [
    {
        "Amsterdam is the capital of which country?": [
			"Netherlands",
			"Japan",
			"Canada",
			"Philippines"
        ]
    },
    {
        "Moscow is the capital of which country?": [
			"Russia",
			"Turkey",
			"Spain",
			"Cuba"
        ]
    },
    {
        "Pretoria is the capital of which country?": [
			"South Africa",
			"United Kingdom",
			"Thailand",
			"Belgium"
        ]
    },
    {
        "Canberra is the capital of which country?": [
			"Australia",
			"Algeria",
			"Turkey",
			"Cuba"
        ]
    },
    {
        "Beijing is the capital of which country?": [
			"China",
			"Iraq",
			"Egypt",
			"Sweden"
        ]
    },
    {
        "Antananarivo is the capital of which country?": [
			"Madagascar",
			"Cuba",
			"China",
			"Czech Republic"
        ]
    },
    {
        "Brussels is the capital of which country?": [
			"Belgium",
			"United States of America",
			"Iraq",
			"Brazil"
        ]
    },
    {
        "New Dehli is the capital of which country?": [
			"India",
			"Iraq",
			"Cuba",
			"Spain"
        ]
    },
    {
        "Brasilia is the capital of which country?": [
			"Brazil",
			"Pakistan",
			"South Korea",
			"Czech Republic"
        ]
    },
    {
        "Berlin is the capital of which country?": [
			"Germany",
			"Iraq",
			"Russia",
			"Sweden"
        ]
    },
    {
        "Seoul is the capital of which country?": [
			"South Korea",
			"Iraq",
			"United Kingdom",
			"India"
        ]
    },
    {
        "Tokyo is the capital of which country?": [
			"Japan",
			"France",
			"Belgium",
			"Egypt"
		]
    },
    {
        "London is the capital of which country?": [
			"United Kingdom",
			"Cuba",
			"Turkey",
			"Spain"
        ]
    },
    {
        "Bangkok is the capital of which country?": [
			"Thailand",
			"India",
			"United Kingdom",
			"Argentina"
        ]
    },
    {
        "Madrid is the capital of which country?": [
			"Spain",
			"Japan",
			"Canada",
			"Philippines"
        ]
    },
    {
        "Ottawa is the capital of which country?": [
			"Canada",
			"Sweden",
			"Indonesia",
			"Russia"
        ]
    },
    {
        "Paris is the capital of which country?": [
			"France",
			"Philippines",
			"Japan",
			"Canada"
        ]
    },
    {
        "Bogota is the capital of which country?": [
			"Colombia",
			"Canada",
			"Russia",
			"Thailand"
        ]
    },
    {
        "Washington is the capital of which country?": [
			"United States of America",
			"Italy",
			"Netherlands",
			"Algeria"
        ]
    },
    {
        "Warsaw is the capital of which country?": [
			"Poland",
			"United States of America",
			"Italy",
			"Netherlands"
        ]
    }
];

var storage = (function () {
    var dynamodb = new AWS.DynamoDB({apiVersion: '2012-08-10'});

    /*
     * The Game class stores all game states for the user
     */
    function Game(session, data) {
        if (data) {
            this.data = data;
        } else {
            this.data = {
                players: [],
                scores: {},
				questioncounts: {}
            };
        }
        this._session = session;
    }

    Game.prototype = {
        isEmptyScore: function () {
            //check if any one had non-zero score,
            //it can be used as an indication of whether the game has just started
            var allEmpty = true;
            var gameData = this.data;
            gameData.players.forEach(function (player) {
                if (gameData.scores[player] !== 0) {
                    allEmpty = false;
                }
            });
            return allEmpty;
        },
        save: function (callback) {
            //save the game states in the session,
            //so next time we can save a read from dynamoDB
            this._session.attributes.currentGame = this.data;
            dynamodb.putItem({
                TableName: 'ScoreKeeperUserData',
                Item: {
                    CustomerId: {
                        S: this._session.user.userId
                    },
                    Data: {
                        S: JSON.stringify(this.data)
                    }
                }
            }, function (err, data) {
                if (err) {
                    console.log(err, err.stack);
                }
                if (callback) {
                    callback();
                }
            });
        }
    };

    return {
		reloadQuestions: function (session, callback) {
		if (session.attributes.allGameNames) {
             //console.log('get reloadGamequestions from session');
			if (callback)
				callback();
		}
		else {
			var allGameNames = [];
            dynamodb.scan({
                TableName: 'GameQuestions'
            }, function (err, data) {
                if (err) {
                    console.log(err, err.stack);
                    session.attributes.allGameNames = ["countrycapital","reindeer"];
                } else {
                    //console.log('get reloadGamequestions from dynamodb');
					data.Items.forEach(function(item) {
						//console.log('item:'+item.GameId.S);
						allGameNames.push(item.GameId.S);
					});
					session.attributes.allGameNames  = allGameNames;
                }
				if (callback)
					callback();
            }
		);
		}
		},
		setQuestions: function (session, callback) {
		if (session.attributes.originalquestions) {
             //console.log('get gamequestions from session');
			if (callback)
				callback();
		}
		else {
			if (session.attributes.gameName) {
				
			}
			else {
				session.attributes.gameName='countrycapital';
			}
            dynamodb.getItem({
                TableName: 'GameQuestions',
                Key: {
                    GameId: {
                        S: session.attributes.gameName
                    }
                }
            }, function (err, data) {
                if (err) {
                    console.log(err, err.stack);
                    session.attributes.originalquestions = originalquestions;
                } else {
                    //console.log('get gamequestions from dynamodb');
                    session.attributes.originalquestions = JSON.parse(data.Item.GameQuestions.S);
                }
				if (callback)
					callback();
            }
		);
		}
		},
        loadGame: function (session, callback) {
            if (session.attributes.currentGame) {
                //console.log('get game from session=' + session.attributes.currentGame);
				if (callback)
					callback(new Game(session, session.attributes.currentGame));
                return;
            }
            dynamodb.getItem({
                TableName: 'ScoreKeeperUserData',
                Key: {
                    CustomerId: {
                        S: session.user.userId
                    }
                }
            }, function (err, data) {
                var currentGame;
                if (err) {
                    //console.log('load game error:');
                    console.log(err, err.stack);
                    currentGame = new Game(session);
                    session.attributes.currentGame = currentGame.data;
					if (callback)
						callback(currentGame);
                } else if (data.Item === undefined) {
                    //console.log('load game data undefined:');
                    currentGame = new Game(session);
                    session.attributes.currentGame = currentGame.data;
					if (callback)
						callback(currentGame);
                } else {
                    //console.log('get game from dynamodb=' + data.Item.Data.S);
                    currentGame = new Game(session, JSON.parse(data.Item.Data.S));
                    session.attributes.currentGame = currentGame.data;
					if (callback)
						callback(currentGame);
                }
            });
        },
        newGame: function (session) {
            return new Game(session);
        }
    };
})();
module.exports = storage;