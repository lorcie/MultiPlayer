/**
    Copyright 2014-2015 Amazon.com, Inc. or its affiliates. All Rights Reserved.

    Licensed under the Apache License, Version 2.0 (the "License"). You may not use this file except in compliance with the License. A copy of the License is located at

        http://aws.amazon.com/apache2.0/

    or in the "license" file accompanying this file. This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific language governing permissions and limitations under the License.
*/

/**
 * This sample shows how to create a Lambda function for handling Alexa Skill requests that:
 *
 * - Multiple slots: has 2 slots (name and score)
 * - Database Interaction: demonstrates how to read and write data to DynamoDB.
 * - NUMBER slot: demonstrates how to handle number slots.
 * - Custom slot type: demonstrates using custom slot types to handle a finite set of known values
 * - Dialog and Session state: Handles two models, both a one-shot ask and tell model, and a multi-turn dialog model.
 *   If the user provides an incorrect slot in a one-shot model, it will direct to the dialog model. See the
 *   examples section for sample interactions of these models.
 *
 * Examples:
 * 
 * Dialog model:
 *  User: "Alexa, ask multi player to reset."
 *  Alexa: "New game started without players. Who do you want to add first?"
 *  User: "Add Bob"
 *  Alexa: "Bob has joined your game"
 *  User: "Add Jeff"
 *  Alexa: "Jeff has joined your game"
 *
 *  (skill saves the new game)
 *
 * // if some changes have been done in database about the games/questions
 *  User: "reload game questions."
 *  Alexa: "Game Questions has been reloaded. You can set game questions, start game. What can I do for you?"
 *
 * // to select some game : countrycapital, reindeer, otherwise the defaut game is counrtycapital 
 *  User: "set game questions"
 *  Alexa: "To update Game Questions: for country capital, you can say 'set questions 1' , for reindeer say 'set questions 2'. Which one do you want?"
 *
 *  User: "set questions one"
 *  Alexa: "Game Questions set with countrycapital, You can now start game."
 *
 *  User: "set questions two"
 *  Alexa: "Game Questions set with reindeer, You can now start game."
 *
 *  User: "start game"
 *  Alexa: "I will ask each player 5 questions, try to get as many right as you can. Just say the number of the answer. Let's begin. Questions for bob 1. Brasilia is the capital of which country? 1. South Korea. 2. Pakistan. 3. Brazil. 4. Czech Republic. "
 *
 *  (skill will prompt 5 consecutives questions for each player : Bob then Jeff)
 *  each correct answer is preceded by an very short applause mp3 sound
 *  each incorrect answer is preceded by a very short boo mp3 sound
 *
 * One-shot model:
 *  User: "what's the current score?"
 *  Alexa: "Jeff has zero points 5 questions and Bob has three points 5 questions"
 */
'use strict';
var AlexaSkill = require('./AlexaSkill'),
    storage = require('./storage'),
    textHelper = require('./textHelper');

var APP_ID = "amzn1.ask.skill.d9b07b70-3e0c-4a80-a94e-1b6f6dd5800b";
var skillContext = {};

	// ------- Skill specific business logic -------
/**
 * When editing your questions pay attention to your punctuation. Make sure you use question marks or periods.
 * Make sure the first answer is the correct one. Set at least 4 answers, any extras will be shuffled in.
 */
var questions=[];
var ANSWER_COUNT = 4;
var GAME_LENGTH = 5;
var CARD_TITLE = "MultiPlayer"; // Be sure to change this for your skill.
var gameQuestions=[];

/**
 * MultiPlayer is a child of AlexaSkill.
 * To read more about inheritance in JavaScript, see the link below.
 *
 * @see https://developer.mozilla.org/en-US/docs/Web/JavaScript/Introduction_to_Object-Oriented_JavaScript#Inheritance
 */
var MultiPlayer = function () {
    AlexaSkill.call(this, APP_ID);
    skillContext.needMoreHelp = true;
};


// Extend AlexaSkill
MultiPlayer.prototype = Object.create(AlexaSkill.prototype);
MultiPlayer.prototype.constructor = MultiPlayer;

    MultiPlayer.prototype.eventHandlers.onSessionStarted = function (sessionStartedRequest, session) {
     console.log("MultiPlayer onSessionStarted requestId: " + sessionStartedRequest.requestId
        + ", sessionId: " + session.sessionId);

    // any session init logic would go here
       //if user said a one shot command that triggered an intent event,
        //it will start a new session, and then we should avoid speaking too many words.
        skillContext.needMoreHelp = false;
    };

    MultiPlayer.prototype.eventHandlers.onLaunch = function (launchRequest, session, response) {
        //Speak welcome message and ask user questions
        //based on whether there are players or not.
        storage.loadGame(session, function (currentGame) {
            var speechOutput = '',
                reprompt;
            if (currentGame.data.players.length === 0) {
                speechOutput += 'MultiPlayer, Let\'s start your game. Who\'s your first player?';
                reprompt = "Please tell me who is your first player?";
            } else if (currentGame.isEmptyScore()) {
                speechOutput += 'MultiPlayer, '
                    + 'you have ' + currentGame.data.players.length + ' player';
                if (currentGame.data.players.length > 1) {
                    speechOutput += 's';
                }
                speechOutput += ' in the game. You can reload game questions, set game questions, add another player, reset, start game or exit. What would you like?';
                reprompt = textHelper.completeHelp;
            } else {
                speechOutput += 'MultiPlayer, You can reload game questions, set game questions, add another player, reset, start game or exit. What can I do for you?';
                reprompt = textHelper.nextHelp;
            }
            response.ask(speechOutput, reprompt);
        });
    };

    MultiPlayer.prototype.eventHandlers.onSessionEnded = function (sessionEndedRequest, session) {
    console.log("onSessionEnded requestId: " + sessionEndedRequest.requestId
        + ", sessionId: " + session.sessionId);

    // any session cleanup logic would go here
   };
  
    MultiPlayer.prototype.intentHandlers = {
		"NewGameIntent": function (intent, session, response) {
			//reset scores for all existing players
			storage.loadGame(session, function (currentGame) {
            if (currentGame.data.players.length === 0) {
                response.ask('New game started. Who\'s your first player?',
                    'Please tell me who\'s your first player?');
                return;
            }
            currentGame.data.players.forEach(function (player) {
                currentGame.data.scores[player] = 0;
                currentGame.data.questioncounts[player] = 0;
            });
            currentGame.save(function () {
                var speechOutput = 'New game started with '
                    + currentGame.data.players.length + ' existing player';
                if (currentGame.data.players.length > 1) {
                    speechOutput += 's';
                }
                speechOutput += '.';
                if (skillContext.needMoreHelp) {
                    speechOutput += 'You can reload game questions, set game questions, add another player, reset, start game or exit. What would you like?';
                    var repromptText = 'You can reload game questions, set game questions, add another player, reset, start game or exit. What would you like?';
                    response.ask(speechOutput, repromptText);
                } else {
                    response.tell(speechOutput);
                }
            });
			});
		},

    "AddPlayerIntent": function (intent, session, response) {
        //add a player to the current game,
        //terminate or continue the conversation based on whether the intent
        //is from a one shot command or not.
        var newPlayerName = textHelper.getPlayerName(intent.slots.PlayerName.value);
        if (!newPlayerName) {
            response.ask('OK. Who do you want to add?', 'Who do you want to add?');
            return;
        }
        storage.loadGame(session, function (currentGame) {
            var speechOutput,
                reprompt;
            if (currentGame.data.scores[newPlayerName] !== undefined) {
                speechOutput = newPlayerName + ' has already joined the game. If done, you can say : start game, or add new player';
                if (skillContext.needMoreHelp) {
                    response.ask(speechOutput + ' What else?', 'What else?');
                } else {
                    response.ask(speechOutput);
                }
                return;
            }
            speechOutput = newPlayerName + ' has joined your game. If done, You can say : start game';
            currentGame.data.players.push(newPlayerName);
            currentGame.data.scores[newPlayerName] = 0;
            currentGame.data.questioncounts[newPlayerName] = 0;
            if (skillContext.needMoreHelp) {
                if (currentGame.data.players.length == 1) {
                    speechOutput += ' Now who\'s your next player?';
                    reprompt = textHelper.nextHelp;
                } else {
                    speechOutput += 'Who is your next player?';
                    reprompt = textHelper.nextHelp;
                }
            }
            currentGame.save(function () {
                if (reprompt) {
                    response.ask(speechOutput, reprompt);
                } else {
                    response.ask(speechOutput);
                }
            });
        });
    },

    "AddScoreIntent": function (intent, session, response) {
        //give a player points, ask additional question if slot values are missing.
        var playerName = textHelper.getPlayerName(intent.slots.PlayerName.value),
            score = intent.slots.ScoreNumber,
            scoreValue;
        if (!playerName) {
            response.ask('sorry, I did not hear the player name, please say that again', 'Please say the name again');
            return;
        }
        scoreValue = parseInt(score.value);
        if (isNaN(scoreValue)) {
            console.log('Invalid score value = ' + score.value);
            response.ask('sorry, I did not hear the points, please say that again', 'please say the points again');
            return;
        }
        storage.loadGame(session, function (currentGame) {
            var targetPlayer, speechOutput = '', newScore;
            if (currentGame.data.players.length < 1) {
                response.ask('sorry, no player has joined the game yet, what can I do for you?', 'what can I do for you?');
                return;
            }
            for (var i = 0; i < currentGame.data.players.length; i++) {
                if (currentGame.data.players[i] === playerName) {
                    targetPlayer = currentGame.data.players[i];
                    break;
                }
            }
            if (!targetPlayer) {
                response.ask('Sorry, ' + playerName + ' has not joined the game. What else?', playerName + ' has not joined the game. What else?');
                return;
            }
            newScore = currentGame.data.scores[targetPlayer] + scoreValue;
            currentGame.data.scores[targetPlayer] = newScore;
 

            speechOutput += scoreValue + ' for ' + targetPlayer + '. ';
            if (currentGame.data.players.length == 1 || currentGame.data.players.length > 3) {
                speechOutput += targetPlayer + ' has ' + newScore + ' in total.';
            } else {
                speechOutput += 'That\'s ';
                currentGame.data.players.forEach(function (player, index) {
                    if (index === currentGame.data.players.length - 1) {
                        speechOutput += 'And ';
                    }
                    speechOutput += player + ', ' + currentGame.data.scores[player];
                    speechOutput += ', ';
                });
            }
            currentGame.save(function () {
                response.tell(speechOutput);
            });
        });
    },

    "TellScoresIntent": function (intent, session, response) {
        //tells the scores in the leaderboard and send the result in card.
        storage.loadGame(session, function (currentGame) {
            var sortedPlayerScores = [],
                continueSession,
                speechOutput = '',
                leaderboard = '';
            if (currentGame.data.players.length === 0) {
                response.tell('Nobody has joined the game.');
                return;
            }
            currentGame.data.players.forEach(function (player) {
                sortedPlayerScores.push({
                    count: currentGame.data.questioncounts[player],
                    score: currentGame.data.scores[player],
                    player: player
                });
            });
            sortedPlayerScores.sort(function (p1, p2) {
				var diff = p2.score - p1.score;
				if (diff === 0)
					diff = p1.count - p2.count; // less questions count is high rank
                return diff;
            });
            sortedPlayerScores.forEach(function (playerScore, index) {
                if (index === 0) {
                    speechOutput += playerScore.player + ' has ' + playerScore.score + 'point ' + playerScore.count + 'question';
                    if (playerScore.score > 1) {
                        speechOutput += 's';
                    }
                } else if (index === sortedPlayerScores.length - 1) {
                    speechOutput += 'And ' + playerScore.player + ' has ' + playerScore.score + 'point ' + playerScore.count + 'question';
                } else {
                    speechOutput += playerScore.player + ', ' + playerScore.score + 'point ' + playerScore.count + 'question';
                }
                speechOutput += '. ';
                leaderboard += 'No.' + (index + 1) + ' - ' + playerScore.player + ' : ' + playerScore.score + ' / ' + playerScore.count+ ' question\n';
            });
            //currentGame.save(function () {
				response.tellWithCard(speechOutput, "Leaderboard", leaderboard);
            //});
        });
    },

    "ResetPlayersIntent": function (intent, session, response) {
        //remove all players
        storage.newGame(session).save(function () {
            response.ask('New game started without players, who do you want to add first?', 'Who do you want to add first?');
        });
    },

    "AMAZON.HelpIntent": function (intent, session, response) {
        var speechOutput = textHelper.completeHelp;
        if (skillContext.needMoreHelp) {
            response.ask(textHelper.completeHelp + ', what can I do for you?', 'what can I do for you?');
        } else {
            response.ask(textHelper.completeHelp+', what can I do for you?','what can I do for you?');
        }
    },

    "AMAZON.CancelIntent": function (intent, session, response) {
        if (skillContext.needMoreHelp) {
            response.tell('Okay.  Whenever you are ready, you can start adding players in your game.');
        } else {
            response.tell('');
        }
    },

    "AMAZON.StopIntent": function (intent, session, response) {
        if (skillContext.needMoreHelp) {
            response.tell('Okay.  Whenever you are ready, you can start adding players in your game.');
        } else {
            response.tell('');
        }
    },

// game specific intent
	"AMAZON.NoIntent": function (intent, session, response) {
       if (skillContext.needMoreHelp) {
            response.tell('Good bye!');
        } else {
            response.tell('');
        }
    },

	"AMAZON.YesIntent": function (intent, session, response) {
    // Repeat the previous speechOutput and repromptText from the session attributes if available
    // else start a new game session
    if (!session.attributes || !session.attributes.speechOutput) {
        getWelcomeResponse(session,response);
    } else {
		response.ask(session.attributes.speechOutput, session.attributes.repromptText);
    }
   },
	"AMAZON.StartOverIntent": function (intent, session, response) {
    // start a new game session
     getWelcomeResponse(session,response);
   },
   
	"AMAZON.RepeatIntent": function (intent, session, response) {
    // Repeat the previous speechOutput and repromptText from the session attributes if available
    // else start a new game session
    if (!session.attributes || !session.attributes.speechOutput) {
        getWelcomeResponse(session,response);
    } else {
		response.ask(session.attributes.speechOutput, session.attributes.repromptText);
    }
   },

    "AnswerIntent": function (intent, session, response) {
        handleAnswerRequest(intent, session, response);
    },

    "AnswerOnlyIntent": function (intent, session, response) {
        handleAnswerRequest(intent, session, response);
    },

    "DontKnowIntent": function (intent, session, response) {
        handleAnswerRequest(intent, session, response);
    },

    "GameQuestionsReloadIntent": function (intent, session, response) {
		storage.reloadQuestions(session, function() {
		response.ask("Game Questions has been reloaded. You can set game questions, start game. What can I do for you?","Game Questions has been reloaded. You can set game questions, start game. What can I do for you?");			
		});
    },

    "GameQuestionsSetIntent": function (intent, session, response) {
        response.ask("To update Game Questions: for country capital, you can say 'set questions 1' , for reindeer say 'set questions 2'. Which one do you want?","To update Game Questions: for country capital, you can say 'set questions 1' , for reindeer say 'set questions 2'. Which one do you want?");
    },

    "AnswerQuestionsIntent": function (intent, session, response) {
		var answerSlotValid = isAnswerSlotValid(intent);
		var gameQuestions = ["countrycapital","reindeer"];
		if (session.attributes.allGameNames)
			gameQuestions = session.attributes.allGameNames;
		var gameQuestionsIndex = 1;
		if (answerSlotValid) {
			 gameQuestionsIndex = parseInt(intent.slots.Answer.value);
			 //console.log("gameQuestionsIndex="+gameQuestionsIndex);
			 if (gameQuestionsIndex > gameQuestions.length || gameQuestionsIndex < 1)
				 gameQuestionsIndex = 1;
		}
		session.attributes.gameName=gameQuestions[gameQuestionsIndex - 1];
		session.attributes.originalquestions = undefined;
        response.ask("Game Questions set with "+gameQuestions[gameQuestionsIndex - 1]+", You can now start game.","You can start game");
    }	
};

function getWelcomeResponse(session,response) {
	if (session.attributes.currentGame == undefined) {
		//console.log('getWelcomeResponse>currentGame needs to be set');
        storage.newGame(session).save(function () {
            response.ask('New game started without players, who do you want to add first?', 'Who do you want to add first?');
        });
	}
	else {
    storage.setQuestions(session, function() {
	//console.log('get gamequestions from welcome:'+session.attributes.originalquestions);
	questions = session.attributes.originalquestions;
	
    var    speechOutput = "I will ask each player " + GAME_LENGTH.toString()
            + " questions, just say the number of the answer, ",
        shouldEndSession = false,

        gameQuestions = populateGameQuestions(questions),
        correctAnswerIndex = Math.floor(Math.random() * (ANSWER_COUNT)), // Generate a random index for the correct answer, from 0 to 3
        roundAnswers = populateRoundAnswers(questions,gameQuestions, 0, correctAnswerIndex),
		currentPlayerIndex = 0,
        currentQuestionIndex = 0,
        spokenQuestion = Object.keys(questions[gameQuestions[currentQuestionIndex]])[0],
        repromptText,

        i, j, playerName;
	
	if (session.attributes.playerIdx)
		currentPlayerIndex = parseInt(session.attributes.playerIdx);
	else
		currentPlayerIndex = 0;
	if (session.attributes.currentGame) {
		playerName = session.attributes.currentGame.players[currentPlayerIndex];
		if (playerName) {
			repromptText = "Current Player : "+playerName+ ", Questions 1. " + spokenQuestion + " ";
			session.attributes.playerIdx= currentPlayerIndex;
			session.attributes.lastPlayerName= playerName;
			session.attributes.score= parseInt(session.attributes.currentGame.scores[playerName]);
			session.attributes.currentGame.questioncounts[playerName] = parseInt(session.attributes.currentGame.questioncounts[playerName]) + 1;
		}
		else {
			//console.log('current game without player:');
			// mono player
			repromptText = "Questions 1. " + spokenQuestion + " ";
			session.attributes.playerIdx= 0;
			session.attributes.score= 0;
		}
	}
	else { // mono player	
			//console.log('no current game:');	
			repromptText = "Questions 1. " + spokenQuestion + " ";
			session.attributes.playerIdx= 0;
			session.attributes.score= 0;
	}


    for (i = 0; i < ANSWER_COUNT; i++) {
        repromptText += (i+1).toString() + ". " + roundAnswers[i] + ". "
    }
    speechOutput += repromptText;
	
        session.attributes.speechOutput= repromptText;
        session.attributes.repromptText= repromptText;
        session.attributes.currentQuestionIndex= currentQuestionIndex;
        session.attributes.correctAnswerIndex= correctAnswerIndex + 1;
        session.attributes.questions= gameQuestions;

        session.attributes.correctAnswerText=
            questions[gameQuestions[currentQuestionIndex]][Object.keys(questions[gameQuestions[currentQuestionIndex]])[0]][0];   
    
			response.askWithCard(speechOutput, repromptText, CARD_TITLE, speechOutput);
	});
	}
}


function populateGameQuestions(questions) {
    var gameQuestions = [];
    var indexList = [];
    var index = questions.length;

    if (GAME_LENGTH > index){
        throw "Invalid Game Length.";
    }

    for (var i = 0; i < questions.length; i++){
        indexList.push(i);
    }

    // Pick GAME_LENGTH random questions from the list to ask the user, make sure there are no repeats.
    for (var j = 0; j < GAME_LENGTH; j++){
        var rand = Math.floor(Math.random() * index);
        index -= 1;

        var temp = indexList[index];
        indexList[index] = indexList[rand];
        indexList[rand] = temp;
        gameQuestions.push(indexList[index]);
    }

    return gameQuestions;
}

function populateRoundAnswers(questions,gameQuestionIndexes, correctAnswerIndex, correctAnswerTargetLocation) {
    // Get the answers for a given question, and place the correct answer at the spot marked by the
    // correctAnswerTargetLocation variable. Note that you can have as many answers as you want but
    // only ANSWER_COUNT will be selected.
    var answers = [],
        answersCopy = questions[gameQuestionIndexes[correctAnswerIndex]][Object.keys(questions[gameQuestionIndexes[correctAnswerIndex]])[0]],
        temp, i;

    var index = answersCopy.length;

    if (index < ANSWER_COUNT){
        throw "Not enough answers for question.";
    }

    // Shuffle the answers, excluding the first element.
    for (var j = 1; j < answersCopy.length; j++){
        var rand = Math.floor(Math.random() * (index - 1)) + 1;
        index -= 1;

        var temp = answersCopy[index];
        answersCopy[index] = answersCopy[rand];
        answersCopy[rand] = temp;
    }

    // Swap the correct answer into the target location
    for (i = 0; i < ANSWER_COUNT; i++) {
        answers[i] = answersCopy[i];
    }
    temp = answers[0];
    answers[0] = answers[correctAnswerTargetLocation];
    answers[correctAnswerTargetLocation] = temp;
    return answers;
}

function handleAnswerRequestForNextPlayer(speech, session, response) {
	questions = session.attributes.originalquestions;
	
    var    speechOutput = speech, // "I will ask you " + GAME_LENGTH.toString() + " questions, just say the number of the answer, ",
        shouldEndSession = false,

        gameQuestions = populateGameQuestions(questions),
        correctAnswerIndex = Math.floor(Math.random() * (ANSWER_COUNT)), // Generate a random index for the correct answer, from 0 to 3
        roundAnswers = populateRoundAnswers(questions,gameQuestions, 0, correctAnswerIndex),
		currentPlayerIndex = 0,
        currentQuestionIndex = 0,
        spokenQuestion = Object.keys(questions[gameQuestions[currentQuestionIndex]])[0],
        repromptText,

        i, j, playerName;
	
	if (session.attributes.playerIdx)
		currentPlayerIndex = parseInt(session.attributes.playerIdx);
	else
		currentPlayerIndex = 0;
	if (session.attributes.currentGame) {
		playerName = session.attributes.currentGame.players[currentPlayerIndex];
		if (playerName) {
			repromptText = " Current Player : "+playerName+ ", Questions 1. " + spokenQuestion + " ";
			session.attributes.playerIdx= currentPlayerIndex;
			session.attributes.lastPlayerName= playerName;
			session.attributes.score= parseInt(session.attributes.currentGame.scores[playerName]);
			session.attributes.currentGame.questioncounts[playerName] = parseInt(session.attributes.currentGame.questioncounts[playerName]) + 1;
		}
		else {
			//console.log('current game without player:');
			// mono player
			repromptText = " Questions 1. " + spokenQuestion + " ";
			session.attributes.playerIdx= 0;
			session.attributes.score= 0;
		}
	}
	else { // mono player	
			//console.log('no current game:');	
			repromptText = " Questions 1. " + spokenQuestion + " ";
			session.attributes.playerIdx= 0;
			session.attributes.score= 0;
	}

    for (i = 0; i < ANSWER_COUNT; i++) {
        repromptText += (i+1).toString() + ". " + roundAnswers[i] + ". "
    }
    speechOutput += repromptText;
	
        session.attributes.speechOutput= repromptText;
        session.attributes.repromptText= repromptText;
        session.attributes.currentQuestionIndex= currentQuestionIndex;
        session.attributes.correctAnswerIndex= correctAnswerIndex + 1;
        session.attributes.questions= gameQuestions;

        session.attributes.correctAnswerText=
            questions[gameQuestions[currentQuestionIndex]][Object.keys(questions[gameQuestions[currentQuestionIndex]])[0]][0];   
    
			storage.loadGame(session, function (currentGame) {
				currentGame.save(function () {
					response.askWithCard(speechOutput, repromptText, CARD_TITLE, speechOutput);	
            });
			});
			
}

function handleAnswerRequest(intent, session, response) {
	if (session.attributes.currentGame == undefined) {
        storage.newGame(session).save(function () {
            response.ask('New game started without players, who do you want to add first?', 'Who do you want to add first?');
        });
	}
	else {
    storage.setQuestions(session, function() {
	questions = session.attributes.originalquestions;
	
    var speechOutput = "";
    var gameInProgress = session.attributes && session.attributes.questions;
    var answerSlotValid = isAnswerSlotValid(intent);
    var userGaveUp = intent.name === "DontKnowIntent";

    if (!gameInProgress) {
        // If the user responded with an answer but there is no game in progress, ask the user
        // if they want to start a new game. Set a flag to track that we've prompted the user.
        session.attributes.userPromptedToContinue = true;
        speechOutput = "There is no game in progress. Do you want to start a new game? ";
		response.askWithCard(speechOutput, speechOutput, CARD_TITLE, speechOutput);
    } else if (!answerSlotValid && !userGaveUp) {
        // If the user provided answer isn't a number > 0 and < ANSWER_COUNT,
        // return an error message to the user. Remember to guide the user into providing correct values.
        var reprompt = session.attributes.speechOutput;
        var speechOutput = "Your answer must be a number between 1 and " + ANSWER_COUNT + ". " + reprompt;
		response.askWithCard(speechOutput, reprompt, CARD_TITLE, speechOutput);
    } else {
        var gameQuestions = session.attributes.questions,
            correctAnswerIndex = parseInt(session.attributes.correctAnswerIndex),
            currentScore = parseInt(session.attributes.score),
            currentQuestionIndex = parseInt(session.attributes.currentQuestionIndex),
            correctAnswerText = session.attributes.correctAnswerText;

        var speechOutputAnalysis = "";
		var isCorrect = undefined;

        if (answerSlotValid && parseInt(intent.slots.Answer.value) == correctAnswerIndex) {
			currentScore++;
			isCorrect = true;			
			// update global scores for current player
			var playerName = session.attributes.lastPlayerName;
			session.attributes.currentGame.scores[playerName] = currentScore;
			
			
            speechOutputAnalysis = "correct. ";
        } else {
			isCorrect = false;
            if (!userGaveUp) {
                speechOutputAnalysis = "wrong. "
            }
            speechOutputAnalysis += "The correct answer is " + correctAnswerIndex + ": " + correctAnswerText + ". ";
        }
        // if currentQuestionIndex is 4, we've reached 5 questions (zero-indexed) and can exit the game session if last player
        if (currentQuestionIndex == GAME_LENGTH - 1) {
			// check if it is last player ?
			if (session.attributes.playerIdx == session.attributes.currentGame.players.length - 1) {
              speechOutput = (userGaveUp ? "" : "That answer is ");
              speechOutput += speechOutputAnalysis + "You got " + currentScore.toString() + " out of "
                + GAME_LENGTH.toString() + " questions correct. Thank you for playing! You can now ask : what is the score";				
			storage.loadGame(session, function (currentGame) {
				currentGame.save(function () {
			  response.askSsmlWithCard("<speak>"+(isCorrect?"<audio src='https://s3-eu-west-1.amazonaws.com/vegacky/applause-short.mp3' />":"<audio src='https://s3-eu-west-1.amazonaws.com/vegacky/boo-short.mp3' />")+speechOutput+"</speak>", "", CARD_TITLE, speechOutput);
            });
			});
			}
			else { // not last player, so repropose questions for next player
				// set turn to next player
              speechOutput = (userGaveUp ? "" : "That answer is ");
              speechOutput += speechOutputAnalysis + "You got " + currentScore.toString() + " out of "
                + GAME_LENGTH.toString() + " questions correct.";				
				session.attributes.playerIdx = parseInt(session.attributes.playerIdx) + 1;
				handleAnswerRequestForNextPlayer(speechOutput, session, response);
			}
        } else {
            currentQuestionIndex += 1;       
			var spokenQuestion = Object.keys(questions[gameQuestions[currentQuestionIndex]])[0];
            // Generate a random index for the correct answer, from 0 to 3
            correctAnswerIndex = Math.floor(Math.random() * (ANSWER_COUNT));
            var roundAnswers = populateRoundAnswers(questions,gameQuestions, currentQuestionIndex, correctAnswerIndex),

                questionIndexForSpeech = currentQuestionIndex + 1,
                repromptText = "Question " + questionIndexForSpeech.toString() + ". " + spokenQuestion + " ";
            for (var i = 0; i < ANSWER_COUNT; i++) {
                repromptText += (i+1).toString() + ". " + roundAnswers[i] + ". "
            }
            speechOutput += (userGaveUp ? "" : "That answer is ");
            speechOutput += speechOutputAnalysis + "Your score is " + currentScore.toString() + ". " + repromptText;
		
                session.attributes.speechOutput= repromptText;
                session.attributes.repromptText= repromptText;
                session.attributes.currentQuestionIndex= currentQuestionIndex;
                session.attributes.correctAnswerIndex= correctAnswerIndex + 1;
                session.attributes.questions= gameQuestions;
                session.attributes.score= currentScore;
                session.attributes.correctAnswerText=
                    questions[gameQuestions[currentQuestionIndex]][Object.keys(questions[gameQuestions[currentQuestionIndex]])[0]][0];

			// increment global questioncount for current player
			var playerName = session.attributes.lastPlayerName;
			session.attributes.currentGame.questioncounts[playerName] = parseInt(session.attributes.currentGame.questioncounts[playerName]) + 1;

			storage.loadGame(session, function (currentGame) {
				currentGame.save(function () {
					response.askSsmlWithCard("<speak>"+(isCorrect?"<audio src='https://s3-eu-west-1.amazonaws.com/vegacky/applause-short.mp3' />":"<audio src='https://s3-eu-west-1.amazonaws.com/vegacky/boo-short.mp3' />")+speechOutput+"</speak>", repromptText, CARD_TITLE, speechOutput);
            });
			});
        }
    }
		});
	}
}

function handleRepeatRequest(intent, session, response) {
    // Repeat the previous speechOutput and repromptText from the session attributes if available
    // else start a new game session
    if (!session.attributes || !session.attributes.speechOutput) {
        getWelcomeResponse(session,response);
    } else {
		response.askWithCard(session.attributes.speechOutput, session.attributes.repromptText, CARD_TITLE, session.attributes.speechOutput);
    }
}

function handleGetHelpRequest(intent, session, response) {
    // Provide a help prompt for the user, explaining how the game is played. Then, continue the game
    // if there is one in progress, or provide the option to start another one.

    // Set a flag to track that we're in the Help state.
    session.attributes.userPromptedToContinue = true;

    // Do not edit the help dialogue. This has been created by the Alexa team to demonstrate best practices.

    var speechOutput = "I will ask you " + GAME_LENGTH + " multiple choice questions. Respond with the number of the answer. "
        + "For example, say one, two, three, or four. To start a new game at any time, say, start game. "
        + "To repeat the last question, say, repeat. "
        + "Would you like to keep playing?",
        repromptText = "To give an answer to a question, respond with the number of the answer . "
        + "Would you like to keep playing?";
        var shouldEndSession = false;
		response.askWithCard(speechOutput, repromptText, CARD_TITLE, speechOutput);
}

function handleFinishSessionRequest(intent, session, response) {
    // End the session with a "Good bye!" if the user wants to quit the game
		response.tellWithCard("Good bye!", CARD_TITLE, "Good bye!");
}

function isAnswerSlotValid(intent) {
    var answerSlotFilled = intent.slots && intent.slots.Answer && intent.slots.Answer.value;
    var answerSlotIsInt = answerSlotFilled && !isNaN(parseInt(intent.slots.Answer.value));
    return answerSlotIsInt && parseInt(intent.slots.Answer.value) < (ANSWER_COUNT + 1) && parseInt(intent.slots.Answer.value) > 0;
}

exports.handler = function (event, context) {
    var skill = new MultiPlayer();
    skill.execute(event, context);
};